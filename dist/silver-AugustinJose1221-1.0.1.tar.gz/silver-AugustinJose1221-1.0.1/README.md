<h1>Silver - A Python shell prompt</h1>

                                                                
                   🏇 Hi-Yo, Silver! Away!                      
                                                                


<p align="justify">Silver is a customizable shell written in Python. Silver can run basic linux and windows commands. The source code of
silver is available at "https://github.com/AugustinJose1221/silver". Making custom commands and configuring commands 
do multiple tasks is possible by making required tweaks to the source code. The entire code is written in Python and 
compatible with Windows and Unix systems. Open issues to raise errors found while installation or runtime. Any 
additional features/commands can be added by making pull requests to the master git branch.</p>

Description
-----------
<p>
Release version &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.0<br>
Author &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Augustin Jose<br>
Python version &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.6<br>
Supported Platforms &nbsp;&nbsp;Windows and UNIX<br>
</p>
