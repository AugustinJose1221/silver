#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  1 19:39:21 2020

@author: augustinjose
"""


import pytest
import os
from ..Git import clone


def test():
    #assert clone() == True, "Return value should True"
    #Add more test cases
    return 0