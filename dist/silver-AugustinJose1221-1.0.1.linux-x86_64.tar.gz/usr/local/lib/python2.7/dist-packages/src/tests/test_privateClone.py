#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  1 19:37:49 2020

@author: augustinjose
"""


import pytest
import os
from ..Git import privateClone


def test():
    #assert privateClone() == True, "Return value should True"
    #Add more test cases
    return 0