#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  1 19:42:02 2020

@author: augustinjose
"""


import pytest
import os
from ..Git import push


def test():
    #assert push(str(os.getcwd())) == True, "Return value should True"
    #Add more test cases
    return 0